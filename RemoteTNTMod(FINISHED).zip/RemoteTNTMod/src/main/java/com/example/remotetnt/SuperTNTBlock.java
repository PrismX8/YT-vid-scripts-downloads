package com.example.remotetnt;

import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;

public class SuperTNTBlock extends Block {
    public SuperTNTBlock() {
        super(Properties.copy(Blocks.TNT).noOcclusion());
    }

    public void detonate(Level level, BlockPos pos) {
        if (!level.isClientSide) {
            level.removeBlock(pos, false);
            level.explode(null, pos.getX(), pos.getY(), pos.getZ(), 100.0F, true, Level.ExplosionInteraction.TNT);
        }
    }

    public void spawnLinkEffect(Level level, BlockPos pos) {
        if (!level.isClientSide) {
            // Create firework with immediate explosion
            ItemStack fireworkStack = new ItemStack(Items.FIREWORK_ROCKET);
            CompoundTag fireworkTag = fireworkStack.getOrCreateTagElement("Fireworks");
            ListTag explosions = new ListTag();
            CompoundTag explosion = new CompoundTag();

            // Configure explosion
            explosion.putByte("Type", (byte)4); // Star-shaped explosion
            explosion.putIntArray("Colors", new int[]{0xFF0000}); // Red color
            explosions.add(explosion);
            fireworkTag.putByte("Flight", (byte)0);
            fireworkTag.put("Explosions", explosions);

            // Spawn firework at TNT position
            FireworkRocketEntity firework = new FireworkRocketEntity(level,
                pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                fireworkStack);

            CompoundTag entityTag = new CompoundTag();
            entityTag.putInt("LifeTime", 0);
            firework.addAdditionalSaveData(entityTag);

            level.addFreshEntity(firework);
        }
    }
}