package com.example.remotetnt;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final RegistryObject<Item> REMOTE_DETONATOR = RemoteTNTMod.ITEMS.register("remote_detonator",
            () -> new RemoteDetonatorItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> SUPER_TNT = RemoteTNTMod.ITEMS.register("super_tnt",
            () -> new BlockItem(ModBlocks.SUPER_TNT.get(), new Item.Properties()));

    public static void register() {}
}
