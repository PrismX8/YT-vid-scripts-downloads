package com.example.remotetnt;

import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final RegistryObject<Block> SUPER_TNT = RemoteTNTMod.BLOCKS.register("super_tnt", SuperTNTBlock::new);
    public static void register() {}
}
